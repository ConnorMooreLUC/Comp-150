'''
TITLE: Ex-3-1-a
AUTHOR: Connor Moore
DATE: 2.1.17
DESCRIPTION: Prints the phrase "All work and no play makes Jack a dull boy." 100 times.
MODIFICATION HISTORY AND OUTSIDE RESOURCES:
Last Updated 2.1;

'''
phrase = "All work and no play makes Jack a dull boy.  "
print(100*phrase)


